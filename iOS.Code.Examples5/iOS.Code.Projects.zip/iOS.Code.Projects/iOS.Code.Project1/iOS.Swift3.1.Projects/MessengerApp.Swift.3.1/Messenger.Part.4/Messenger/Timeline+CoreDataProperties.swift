//
//  Timeline+CoreDataProperties.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Timeline {

    @NSManaged var userID: NSNumber?
    @NSManaged var user: String?
    @NSManaged var createdAt: Date?
    @NSManaged var message: String?

}

//
//  StatusViewController.swift
//  Messenger
//
//  Created by XCode on 7/24/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit

class StatusViewController: UIViewController, UITextViewDelegate {


    let preferences = UserDefaults.standard
    @IBOutlet weak var textCount: UILabel!
    @IBOutlet weak var statusView: UITextView!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.statusView.delegate = self
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tweetButtonClickHandle(_ sender: AnyObject)
    {
        self.statusView.resignFirstResponder()
        print(self.statusView.text!)
        MessengerClient.sharedMessengerClient.postStatus(self.statusView.text!)
        self.statusView.text = ""
    }
    
    @IBAction func refreshServiceClickHandle(_ sender: AnyObject)
    {
        let frequencyValue = Int(self.preferences.object(forKey: SettingsViewController.REFRESH_INTERVAL_KEY) as! String)
        let refreshService = RefreshService(frequency: frequencyValue!)
        refreshService.startService()
    }
    
    //MARK:- UI Text View Delegate Methods
    func textViewDidChange(_ textView: UITextView)
    {
        let textLength = 140 - self.statusView.text.characters.count
        self.textCount.text = String(stringInterpolationSegment: textLength)
        if (textLength <= 30 && textLength >= 11)
        {
            self.textCount.textColor = UIColor.orange
            
        }
        else if (textLength <= 10 && textLength >= 0)
        {
            self.textCount.textColor = UIColor.red;
        }

    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
    {
        if text == "\n"
        {
            textView.resignFirstResponder()
            return false
        }
        else if ((140 - self.statusView.text.characters.count) <= 0)
        {
            return false
        }
        return true
    }
    
    @IBAction func settingButtonClickHandle(_ sender: AnyObject)
    {
        let settingsViewController = self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController") as! SettingsViewController
        navigationController?.pushViewController(settingsViewController,
                                                 animated: true)
        
    }
}


//
//  MessengerClient.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit

class MessengerClient: NSObject
{
    static let sharedMessengerClient = MessengerClient()
    
    var dataTask: URLSessionDataTask?
    var dataUploadTask: URLSessionUploadTask?
    let DEFAULT_API_ROOT:String = "http://127.0.0.1:8000/status/"
    fileprivate var statuses = NSMutableArray()
    fileprivate var maxPost: Int = 30
    let preferences = UserDefaults.standard
    
    func postStatus(_ status: String)
    {
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let defaultSession = URLSession(configuration: URLSessionConfiguration.default, delegate: nil, delegateQueue: nil)
        
        let url = URL(string: DEFAULT_API_ROOT + "postStatus1/")
        var urlRequest = URLRequest(url: url!)
        urlRequest.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        var postData: Data?
        
        let username = self.preferences.object(forKey: SettingsViewController.USER_NAME_KEY)!
        let password = self.preferences.object(forKey: SettingsViewController.PASSWORD_KEY)!
        
        let postDictionary = NSDictionary(objects: [status, username, password], forKeys: ["Status" as NSCopying, "Username" as NSCopying, "Password" as NSCopying])
        do
        {
            postData = try JSONSerialization.data(withJSONObject: postDictionary, options: JSONSerialization.WritingOptions.init(rawValue: 0))
        }
        catch
        {
            let jsonError = error as NSError
            print("\(jsonError), \(jsonError.userInfo)")
        }
        urlRequest.httpMethod = "POST"
        urlRequest.httpBody = postData
        
        self.dataTask = defaultSession.dataTask(with: urlRequest, completionHandler:
        {
            data, response, error in
            
            DispatchQueue.main.async {
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
            
            if let error = error {
                print(error.localizedDescription)
            }
            else if let httpResponse = response as? HTTPURLResponse
            {
                if httpResponse.statusCode == 200
                {
                    DispatchQueue.main.async {
                        UIAlertView(title: "Status Posting", message: "Status Posted Successfully", delegate: nil, cancelButtonTitle: "OK").show()
                    }

                }
                else
                {
                    print(httpResponse.statusCode)
                }
            }
        })
        self.dataTask?.resume()
    }
    
    func getTimeline(_ count: Int) -> NSMutableArray
    {
        self.maxPost = count
        self.fetchFriendsTimeline()
        return self.statuses
    }
    
    fileprivate func fetchFriendsTimeline()
    {
        let defaultSession = URLSession(configuration: URLSessionConfiguration.default, delegate: nil, delegateQueue: nil)
        let url = URL(string: DEFAULT_API_ROOT + "gettimeline/")
        self.dataTask = defaultSession.dataTask(with: url!, completionHandler: {
            data, response, error in
            if error == nil
            {
                self.parseStatusMessages(data!)
            }
        })
        self.dataTask?.resume()
    }
    
    fileprivate func parseStatusMessages(_ data: Data)
    {
        var timelineStatus: NSArray!
        do
        {
           timelineStatus = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! NSArray
        }
        catch
        {
            let error = error as NSError
            print("\(error), \(error.userInfo)")
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss+zz:zz"
        self.statuses.removeAllObjects()
        for count in 0 ..< timelineStatus.count
        {
            let statusID = (timelineStatus.object(at: count) as AnyObject).object(forKey: "id") as! Double
            let time = (timelineStatus.object(at: count) as AnyObject).object(forKey: "time") as! String
            let userName = (timelineStatus.object(at: count) as AnyObject).object(forKey: "studentName") as! String
            let message = (timelineStatus.object(at: count) as AnyObject).object(forKey: "status") as! String
            self.timelineStatusParse(statusID, createdDate: dateFormatter.date(from: time)!,
                createdUserName: userName , userMessage: message)
        }
    }
    
    fileprivate func timelineStatusParse(_ statusID:Double, createdDate createdAt: Date, createdUserName userName: String, userMessage message:String)
    {
        self.statuses.add(Status(statusID: statusID, createdDate: createdAt, createdUserName: userName, userMessage: message))
    }
    
    
    
}

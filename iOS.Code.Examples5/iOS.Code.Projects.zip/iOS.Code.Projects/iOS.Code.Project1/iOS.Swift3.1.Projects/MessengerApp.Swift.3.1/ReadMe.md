##Server Configuration

####Step 1: Installing Virtual Environment

1. sudo easy\_install pip
2. sudo pip install virtualenv
3. sudo pip install virtualenvwrapper
4. cd $home
5. mkdir .virtualenv
6. vim .base\_login
7. inside the file type the following command
	* source /usr/local/bin/virtualenvwrapper.sh
8. close the terminal and open again
9. Testing : type mkvirtualenv

####Step 2: Creating Virtual Environment

1. mkvirtualenv "virtulaenv name"
2. workon "virtaulenv name"

####Step 3: Installing MySQL-Server

1. Download and install latest MySQL-Server
2.  export PATH=$PATH:/usr/local/mysql/bin/
3. Start MySQL Server In System Preferences
3. Download and install latest MySQL-Workbench-Community.
	- Connect with LocalHost: Click On It
	- Supply Password
4. Open MySQL-Workbench and Test the connection.


<!--
2016-12-10T11:05:06.886408Z 1 [Note] A temporary password is generated for root@localhost: <Q6V;>f:8o8g

-->

####Step 4: Installing django

1. Open the terminal
2. Activate created virtual environment.
3. Install Django
	pip install Django==1.7

####Step 5: Configure Python-MySQL db connection:

1. Open the terminal
2. Activate created virtual environment.
3. pip install MySQL-python.
	- ERROR: 
		- Not Able to Access MySQL PATH
	- RESOLUTION:
	   - export PATH=$PATH:/usr/local/mysql/bin
	

####Step 6: Copy the project

1. Copy the project on local directory
2. Open the terminal, go to the directory

####Step 7: Configure the server and database

1. Go to the root of the project directory. Example : ParappuServer
	- Modify ParappuClient/settings.py
	- Add DB Name "MessengerDB"
	- Add Password
2. Create "MessengerDB" Using MySQLWorkBench 
2. Migrate the database throw following command
	- For <= Django v1.5 
		* python manage.py makemigration
	* OR
	- For > Django v1.5 
		* python manage.py migrate
3. Run Django Web Server using following command
	* python manage.py runserver

####Step 7: Access Web Page in Browser To See Messages
	http://127.0.0.1:8000/status


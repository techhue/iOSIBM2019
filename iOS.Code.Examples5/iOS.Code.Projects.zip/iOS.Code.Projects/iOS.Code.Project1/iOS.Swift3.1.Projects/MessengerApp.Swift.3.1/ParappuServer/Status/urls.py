from django.conf.urls import url, patterns

from Status import views

urlpatterns = patterns('',
	# ex : /status/
	url(r'^$', views.index, name = 'index'),

	# ex : /status/postStatus/
	url(r'^postStatus/$', views.postStatus, name = 'postStatus'),

	# ex : /status/postStatus1/
	url(r'^postStatus1/$', views.postStatus1, name = 'postStatus1'),

	# ex : /status/gettimeline/
	url(r'^gettimeline/$', views.getTimeline, name = 'getTimeline')
)
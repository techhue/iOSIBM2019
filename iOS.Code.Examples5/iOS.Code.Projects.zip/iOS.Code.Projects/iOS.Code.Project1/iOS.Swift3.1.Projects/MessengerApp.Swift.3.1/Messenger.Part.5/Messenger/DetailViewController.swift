//
//  DetailViewController.swift
//  Messenger
//
//  Created by XCode on 7/28/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var createdAtLabel: UILabel!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    
    var selectedTimeline: Timeline!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.userNameLabel.text = self.selectedTimeline.user!
        self.messageLabel.text = self.selectedTimeline.message!
        self.createdAtLabel.text = self.selectedTimeline.createdAt!.description
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backButtonClickHandler(_ sender: AnyObject)
    {
        dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


func overflowUnderflow() {
	var a: Int8 = 127
	let b  = a + 1
	
	let d: UInt8 = 255 
	let c = d + 1
}

func main() {

	print("Function: overflowUnderflow")
	overflowUnderflow()
}

main()



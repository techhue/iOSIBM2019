#import <UIKit/UIKit.h>


@interface ShakeView : UIView {

}

@property (nonatomic, retain) id shakeDelegate;

@end

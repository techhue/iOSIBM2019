
let b = 10
var a = 5

a = b

//
//  ViewController.swift
//  UIGestureRecognizer3
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {
    
    var imageView: UIImageView?
    
    override func loadView()
    {
        super.loadView()
        self.imageView = UIImageView(image: UIImage(named: "apple.png"))
        self.imageView!.frame = CGRect(x: 0, y: 0, width: 150, height: 150)
        self.imageView!.center = self.view.center
        self.imageView!.isUserInteractionEnabled = true
        configureRotationGesture()
        self.view.addSubview(self.imageView!)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureRotationGesture()
    {
        print("%s", #function)
        let rotation: UIRotationGestureRecognizer = UIRotationGestureRecognizer(target: self,
            action: #selector(ViewController.handleRotationGestureRecognizer(_:)))
        rotation.delegate = self
        self.imageView!.addGestureRecognizer(rotation)
    }
    
    func handleRotationGestureRecognizer(_ sender: UIRotationGestureRecognizer)
    {
        print("%s", #function)
        if(sender.state == UIGestureRecognizerState.changed)
        {
            let rotation: CGFloat = sender.rotation
            sender.view?.transform = sender.view!.transform.rotated(by: rotation)
            sender.rotation = 0
        }
    }


}


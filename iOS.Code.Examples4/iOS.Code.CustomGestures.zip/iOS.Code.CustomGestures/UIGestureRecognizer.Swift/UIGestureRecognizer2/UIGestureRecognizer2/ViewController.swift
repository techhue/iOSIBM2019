//
//  ViewController.swift
//  UIGestureRecognizer2
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit
import QuartzCore

class ViewController: UIViewController {
    
    var firstView: UIView?
    var secondView: UIView?
    
    override func loadView()
    {
        super.loadView()
        
        self.secondView = UIView(frame: self.view.bounds)
        self.secondView!.backgroundColor = UIColor.orange
        self.secondView!.isHidden = true
        self.view.addSubview(self.secondView!)
        
        var label: UILabel = titleLable()
        label.text = "SECOND VIEW"
        label.center = self.secondView!.center
        self.secondView!.addSubview(label)
        
        self.firstView = UIView(frame: self.view.bounds)
        self.firstView!.backgroundColor = UIColor.lightGray
        self.firstView!.isHidden = false
        self.view.addSubview(self.firstView!)
        
        label = titleLable()
        label.text = "FIRST VIEW"
        label.center = self.firstView!.center
        self.firstView!.addSubview(label)
        
        configureLeftSwipeGesture()
        configureRightSwipeGesture()
        configureLongPressGesture()
        
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureLeftSwipeGesture()
    {
        let leftSwipe: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self,
            action: #selector(ViewController.handleLeftSwipeGestureRecognizer(_:)))
        leftSwipe.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(leftSwipe)
    }
    
    func configureRightSwipeGesture()
    {
        let rightSwipe: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self,
            action: #selector(ViewController.handleRightSwipeGestureRecognizer(_:)))
        rightSwipe.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(rightSwipe)
    }
    
    func configureLongPressGesture()
    {
        let longPress: UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self,
            action: #selector(ViewController.handleLongPressGestureRecognizer(_:)))
        longPress.numberOfTouchesRequired = 1
        longPress.minimumPressDuration = 0.5
        self.view.addGestureRecognizer(longPress)
    }
    
    func handleLeftSwipeGestureRecognizer(_ sender: UISwipeGestureRecognizer)
    {
        let transition: CATransition = CATransition()
        transition.startProgress = 0.0
        transition.endProgress = 1.0
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromRight
        transition.duration = 1.0
        
        self.firstView!.layer.add(transition, forKey: "transition")
        self.secondView!.layer.add(transition, forKey: "transition")
        
        self.firstView!.isHidden = true
        self.secondView!.isHidden = false
        
    }
    
    func handleRightSwipeGestureRecognizer(_ sender: UISwipeGestureRecognizer)
    {
        let transition: CATransition = CATransition()
        transition.startProgress = 0.0
        transition.endProgress = 1.0
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromLeft
        transition.duration = 1.0
        
        self.secondView!.layer.add(transition, forKey: "transition")
        self.firstView!.layer.add(transition, forKey: "transition")
        
        self.firstView!.isHidden = false
        self.secondView!.isHidden = true
    }
    
    func handleLongPressGestureRecognizer(_ sender: UILongPressGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.began)
        {
            let alertView: UIAlertView = UIAlertView(title: "Long Press Gesture",
                message: "Removed Current View",
                delegate: nil,
                cancelButtonTitle: "OK")
            alertView.show()
            
            if(self.firstView!.isHidden && self.secondView != nil)
            {
                self.secondView!.removeFromSuperview()
                self.firstView!.isHidden = false
            }
            if(self.secondView!.isHidden && self.firstView != nil)
            {
                self.firstView!.removeFromSuperview()
                self.secondView!.isHidden = false
            }
        }
    }
    
    func titleLable() -> UILabel
    {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 50))
        label.backgroundColor = UIColor.clear
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 20)
        return label
    }

}


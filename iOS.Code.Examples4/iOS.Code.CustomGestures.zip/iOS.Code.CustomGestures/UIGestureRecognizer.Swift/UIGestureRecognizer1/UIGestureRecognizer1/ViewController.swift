//
//  ViewController.swift
//  UIGestureRecognizer1
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var imageView: UIImageView?
    
    override func loadView()
    {
        super.loadView()
        configureSingleTapGesture()
        configureDoubleTapGesture()
        let singleTap: UITapGestureRecognizer = self.view.gestureRecognizers![0] as! UITapGestureRecognizer
        singleTap.require(toFail: self.view.gestureRecognizers![1] as! UITapGestureRecognizer)
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureSingleTapGesture()
    {
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(ViewController.handleSingleTapGestureRecognizer(_:)))
        singleTap.numberOfTapsRequired = 1;
        singleTap.numberOfTouchesRequired = 1
        self.view.addGestureRecognizer(singleTap)
    }
    
    func configureDoubleTapGesture()
    {
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(ViewController.handleDoupleGestureRecognizer(_:)))
        doubleTap.numberOfTapsRequired = 2;
        doubleTap.numberOfTouchesRequired = 1
        self.view.addGestureRecognizer(doubleTap)
    }
    
    func configurePanGesture()
    {
        let pan: UIPanGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(ViewController.handlePanGestureRecognizer(_:)))
        pan.minimumNumberOfTouches = 1
        pan.maximumNumberOfTouches = 1
        self.imageView!.addGestureRecognizer(pan)
    }
    
    func configurePinchGesture()
    {
        let pinch: UIPinchGestureRecognizer = UIPinchGestureRecognizer(target: self, action: #selector(ViewController.handlePinchGestureRecognizer(_:)))
        self.imageView!.addGestureRecognizer(pinch)
    }
    
    func handleSingleTapGestureRecognizer(_ sender: UITapGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.ended)
        {
            if(self.imageView == nil)
            {
                self.imageView = UIImageView(image: UIImage(named: "apple.png"))
                self.imageView!.frame = CGRect(x: 0, y: 0, width: 150, height: 150)
                self.imageView!.center = self.view.center
                self.imageView!.isUserInteractionEnabled = true
                self.view.addSubview(self.imageView!)
                configurePanGesture()
                configurePinchGesture()
            }
        }
    }
    
    func handleDoupleGestureRecognizer(_ sender: UITapGestureRecognizer )
    {
        if(sender.state == UIGestureRecognizerState.ended)
        {
            if(self.imageView != nil)
            {
                self.imageView!.removeFromSuperview()
                self.imageView = nil
            }
        }
    }
    
    func handlePanGestureRecognizer(_ sender: UIPanGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.changed)
        {
            let translation: CGPoint = sender.translation(in: sender.view!)
            sender.view?.center = CGPoint(x: sender.view!.center.x + translation.x,
                y: sender.view!.center.y + translation.y)
            sender.setTranslation(CGPoint(x: 0, y: 0), in: sender.view)
        }
    }
    
    func handlePinchGestureRecognizer(_ sender: UIPinchGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.changed)
        {
            let scale: CGFloat = sender.scale
            sender.view?.transform = sender.view!.transform.scaledBy(x: scale, y: scale)
            sender.scale = 1
        }
    }

}


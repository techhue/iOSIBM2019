//
//  RandomNumber.h
//  RandomNumbers
//
//  Created by Ravi Shankar on 29/04/14.
//  Copyright (c) 2014 Ravi Shankar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RandomNumber : NSObject

-(NSInteger) generateNumber;

@end

#import <UIKit/UIKit.h>

@interface ShakeViewController : UIViewController {

}

@property (nonatomic, retain) IBOutlet UIImageView *theDie;
@property (nonatomic, assign) BOOL shaking;

@end


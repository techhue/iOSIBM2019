//
//  Copyright © 2015 Big Nerd Ranch
//

import Foundation
import CoreGraphics

struct Line {
    
    var begin = CGPoint.zero
    var end = CGPoint.zero
}
